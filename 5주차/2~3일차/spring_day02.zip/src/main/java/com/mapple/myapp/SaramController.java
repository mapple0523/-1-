package com.mapple.myapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SaramController {

	@RequestMapping("/list") // 맵핑을 /saram/list로 해놧기때문에 주소에서도 myapp/saram/list로 해야 들어가짐
	public String saram() {
		System.out.println("SaramController의 saram() 메소드 호출");

		return "saram/list"; // WEB-INF/views/saram/list.jsp를 보여줌
	}

	@RequestMapping("/input")
	public String input() {
		System.out.println("SaramController의 input() 메소드 호출");

		return "saram/input";
	}
}
