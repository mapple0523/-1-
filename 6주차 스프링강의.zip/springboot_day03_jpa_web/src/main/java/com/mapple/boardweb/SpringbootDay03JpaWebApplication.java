package com.mapple.boardweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDay03JpaWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDay03JpaWebApplication.class, args);
	}

}
