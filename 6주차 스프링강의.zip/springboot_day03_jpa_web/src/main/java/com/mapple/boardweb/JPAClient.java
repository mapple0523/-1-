package com.mapple.boardweb;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.mapple.boardweb.domain.Board;

public class JPAClient {
	public static void main(String[] args) {
		insert();
		select();
	}

	public static void insert() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Board");

		EntityManager em = emf.createEntityManager();

		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();

			Board board = new Board();
			board.setTitle("제목");
			board.setWriter("이민재");
			board.setContent("내용");
			board.setCreateDate(new Date());
			board.setCnt(0L);
			em.persist(board);

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
			emf.close();
		}
	}
	
	public static void select() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Board");
		EntityManager em = emf.createEntityManager();
		try {
			Board board = em.find(Board.class, 2L);
			System.out.println("이건 출력메세지"+board);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
			emf.close();
		}
	}
	
	

}
