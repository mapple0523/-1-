package com.mapple.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDay03RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
