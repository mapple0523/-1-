package com.mapple.todo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapple.todo.domain.TodoEntity;
import com.mapple.todo.dto.TodoDTO;
import com.mapple.todo.repository.TodoRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TodoService {
	@Autowired
	private TodoRepository repository; 
	//기존 프로젝트의 DAO 역할. 
	
	public void validate(final TodoEntity entity) {
		if(entity == null) {
			log.warn("entity가 null입니다.");
			throw new RuntimeException("entity가 null입니다.");
		}
		if(entity.getUserId() == null) {
			log.warn("userId가 null입니다.");
			throw new RuntimeException("entity가 null입니다.");
		}
	}
	
	//매개 변수로 사용된 entity참조 변수를 이용해서 원본이 바뀌지 않도록 final 선언
	public List<TodoEntity> create(final TodoEntity entity) {
		//유효성 검사(null 체크) 필수
		validate(entity);
		
		repository.save(entity);
		//처리 후 로그 출력
		log.info("Entity id: {} is saved", entity.getId());
		
		return repository.findByUserId(entity.getUserId());
	}
	
	public String testService() {
		TodoEntity todoEntity = TodoEntity.builder().title("제목").build();
		repository.save(todoEntity);
		log.info(todoEntity.getId());
		//새로 추가되는 행의 id를 찾아옴
		TodoEntity savedEntity = repository.findById(todoEntity.getId()).get();
		//새로 추가되는 행의 값을 repository에서 찾아서 가져오고
		return savedEntity.toString();
		//가져온값중에서 title을 뿌려준다~
	}
	
	//검색
	public List<TodoEntity> retrieve(final String userId) {
		return repository.findByUserId(userId);
	}
	
	//수정
	public List<TodoEntity> update(final TodoEntity entity) {
		validate(entity);
		// 검색
		final Optional<TodoEntity> original = repository.findById(entity.getId());
		//새로운 내용으로 수정한다.
		original.ifPresent(todo -> {
			todo.setTitle(entity.getTitle());
			todo.setDone(entity.isDone());
			repository.save(todo);
		});
		// 다시 저장 (update메소드가 따로 없고 save를 활용)
		return retrieve(entity.getUserId());
	}
	
	//삭제
	public List<TodoEntity> delete(final TodoEntity entity) {
		validate(entity);
		
		try {
			repository.delete(entity);
		} catch (Exception e) {
			throw new RuntimeException(entity.getId()+"삭제 시 에러 발생");
		}
		return retrieve(entity.getUserId());
	}
	
	public List<TodoEntity> findAll(){
		return repository.findAll();
		//findAll은 spring에서 가지고 있는 명령어.
	}
}
