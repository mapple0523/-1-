package com.mapple.todo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mapple.todo.domain.TodoEntity;

@Repository
public interface TodoRepository extends JpaRepository<TodoEntity, String> {
//<T, ID> = 엔티티와 엔티티의 primary key의 속성을 적는것
//@Repository는 적어도되고 안적어도되는데 이미 Repository의 annotation을 가지고 있기때문에 안적어도된다.
	
	//findTodoEntityByUserId
	List<TodoEntity> findByUserId(String userId);
	
	//네이티브 쿼리는 실제 dbms에서 사용되는 SQL을 사용한다.
	@Query(value ="SELECT t FROM TodoEntity AS t  WHERE t.userId = ?1", nativeQuery = true)
	List<TodoEntity> findByUserIdQuery(String userId);
	
	
	//
	@Query(value ="SELECT t FROM TodoEntity AS t  WHERE t.userId = ?1")
	List<TodoEntity> findByUserIdQuery2(String userId);


	


}


