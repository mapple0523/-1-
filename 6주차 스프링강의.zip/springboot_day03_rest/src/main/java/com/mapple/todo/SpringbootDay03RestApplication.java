package com.mapple.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDay03RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDay03RestApplication.class, args);
	}

}
