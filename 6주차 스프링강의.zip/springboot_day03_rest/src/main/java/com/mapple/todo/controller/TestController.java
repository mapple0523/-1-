package com.mapple.todo.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mapple.todo.dto.ResponseDTO;
import com.mapple.todo.dto.TestRequestBodyDTO;
import com.mapple.todo.dto.TodoDTO;
import com.mapple.todo.service.TodoService;

@RestController
public class TestController {
	@Autowired
	TodoService todoService;
	
	@GetMapping("/todo/test")
	public String todoTest() {
		return todoService.testService();
	}
	
	@GetMapping("/")
	public String hello() {
		//@RestController를 사용하면
		//리턴되는 문자열이 브라우저에 바로 출력됨
		return "{\"message\":\"Hello \"}";
	}
	
	@PostMapping("/hello")
	public String helloProc(@RequestParam("user") String user, @RequestParam("message") String message) {
		
		  return String.format("{\"user\":\"%s\",\"message\":\"%s\"}", user, message);

	}
	
	@GetMapping("/saram/{id}/{message}")
	public String pathVariables(@PathVariable(required = true) String id,
			@PathVariable String message) {
		//JSONObject 라이브러리 활용;
		//required는 뺼수가 없음 자료가 무조껀 들어가야함.
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("no", 1);
		jsonObj.put("id", id);
		jsonObj.put("message", message);
		return jsonObj.toString(2);
	}
	
	@GetMapping("/requestBody")
	public String reqDTO(@RequestBody TestRequestBodyDTO reqDTO) {
		return reqDTO.toString();
	}
	
	@GetMapping("/requestBody2")
	public TestRequestBodyDTO reqDTO2(@RequestBody TestRequestBodyDTO reqDTO2) {
		return reqDTO2;
	}
	
	@GetMapping("/responseBody")
	public ResponseDTO<String> responseBody() {
		List<String> list = new ArrayList();
		list.add("Hello world");
		ResponseDTO<String> response = ResponseDTO.<String>builder().error("200").data(list).build();
		return response;
	}
	
	@GetMapping("/responseEntity")
	public ResponseEntity<?> responseEntity() {
		//responseEntity는 spring에서 지정해주는 entity이다.
		List<String> list = new ArrayList<String>();
		list.add("Hello World! ");
		ResponseDTO<String> response = ResponseDTO.<String>builder().data(list).build();
		// http status 400
		//return ResponseEntity.badRequest().body(response);
		// http status 200
		return ResponseEntity.ok().body(response);
		
		//http의 상태(오류코드?)를 지정해줄수 있다.
	}
	
	
	
}
