package com.mapple.todo.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mapple.todo.domain.TodoEntity;
import com.mapple.todo.dto.ResponseDTO;
import com.mapple.todo.dto.TodoDTO;
import com.mapple.todo.service.TodoService;

@CrossOrigin("*")
@Controller
@RequestMapping("/todo")
public class TodoController {

	@Autowired
	TodoService Service;

	String tmpUserId = "temporary-user";

	@PostMapping
	public ResponseEntity<?> createTodo(@RequestBody TodoDTO dto) {
		try {
			// 1. Entity로 변환
			TodoEntity entity = dto.toEntity();
			// entity의 아이디는 null이어야한다.(테이블에 insert될때 자동 생성됨)
			entity.setId(null);
			// 임시 UserId 사용
			entity.setUserId(tmpUserId);
			// service를 이용해서 Entity 생성
			List<TodoEntity> entitis = Service.create(entity);
			// TodoEntity 리스트를 TodoDto리스트로 변환.
			List<TodoDTO> dtos = entitis.stream().map(TodoDTO::new).collect(Collectors.toList());
			// 더블 콜론을쓰면 공정이 줄어듬 문법 확인해보기
			ResponseDTO<TodoDTO> reponse = ResponseDTO.<TodoDTO>builder().data(dtos).build();
			// ResponseDTO를 리턴한다.
			return ResponseEntity.ok().body(reponse);

		} catch (Exception e) {
			// 예외 발생 시 처리
			String error = e.getMessage();
			ResponseDTO<TodoDTO> response = ResponseDTO.<TodoDTO>builder().error(error).build();
			return ResponseEntity.badRequest().body(response);

		}
	}

	@GetMapping
	public ResponseEntity<?> findTodo(@RequestBody TodoDTO dto) {
		TodoEntity entity = dto.toEntity();
		// 2. id 초기화
		entity.setUserId(tmpUserId);
		// 3. entity로 업데이트
		List<TodoEntity> entitis = Service.retrieve(dto.getUserId());
		// 4. Entity리스트를 Todo 리스트로 변환
		List<TodoDTO> todos = entitis.stream().map(TodoDTO::new).collect(Collectors.toList());
		// 5. ResponseDTO 초기화
		ResponseDTO<TodoDTO> response = ResponseDTO.<TodoDTO>builder().data(todos).build();
		// 6. ResponseDTO 리턴
		return ResponseEntity.ok().body(response);
	}

	@PutMapping
	public ResponseEntity<?> updateTodo(@RequestBody TodoDTO dto) {
		// 1. dto로 변환
		TodoEntity entity = dto.toEntity();
		// 2. id 초기화
		entity.setUserId(tmpUserId);
		// 3. entity로 업데이트
		List<TodoEntity> entitis = Service.update(entity);
		// 4. Entity리스트를 Todo 리스트로 변환
		List<TodoDTO> todos = entitis.stream().map(TodoDTO::new).collect(Collectors.toList());
		// 5. ResponseDTO 초기화
		ResponseDTO<TodoDTO> response = ResponseDTO.<TodoDTO>builder().data(todos).build();
		// 6. ResponseDTO 리턴
		return ResponseEntity.ok().body(response);
	}

	@DeleteMapping
	public ResponseEntity<?> deleteTodo(@RequestBody TodoDTO dto) {
		try {
			// 1. dto로 변환
			TodoEntity entity = dto.toEntity();
			// 2. id 초기화
			entity.setUserId(tmpUserId);
			// 3. entity로 업데이트
			List<TodoEntity> entitis = Service.delete(entity);
			ResponseDTO<TodoEntity> response = ResponseDTO.<TodoEntity>builder().data(entitis).build();
			// 6. ResponseDTO 리턴
			return ResponseEntity.ok().body(response);
		} catch (Exception e) {
			ResponseDTO<TodoEntity> response = ResponseDTO.<TodoEntity>builder().error("삭제 에러").build();
			return ResponseEntity.ok().body(response);
		}
	}

	@GetMapping("/list")
	public String selectList() {
		String userId = "";
		List<TodoEntity> todoList = Service.findAll();
		System.out.println("todo LIst>>>>>");
		for (TodoEntity todo : todoList) {
			System.out.println(todo);
		} // todoList의 갯수만큼 반복해서 todo에 넣어서 todoList를 전부 꺼내오는것
		return "todo list";
	}
}
