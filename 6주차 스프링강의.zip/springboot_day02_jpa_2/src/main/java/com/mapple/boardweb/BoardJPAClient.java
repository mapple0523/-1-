package com.mapple.boardweb;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.mapple.boardweb.domain.BoardEntity;

public class BoardJPAClient {

	public static void main(String[] args) {
		//
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("BoardWeb");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			
			for(int i=0; i<10; i++) {
			BoardEntity board = new BoardEntity();
			board.setTitle("글쓰기 제목");
			board.setContent("게시 글 내용");
			board.setWriter("관리자");
			board.setWriteDate(new Date());
			em.persist(board);
			}
			
			BoardEntity board = em.find(BoardEntity.class, 3L);
			System.out.println("출력>>"+ board);
			
			tx.commit();
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			em.close();
			emf.close();
			
		}
	}

}
