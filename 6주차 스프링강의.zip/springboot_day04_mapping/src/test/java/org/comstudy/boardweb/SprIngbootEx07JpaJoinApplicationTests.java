package org.comstudy.boardweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprIngbootEx07JpaJoinApplicationTests {

	@Test
	void contextLoads() {
	}

}
