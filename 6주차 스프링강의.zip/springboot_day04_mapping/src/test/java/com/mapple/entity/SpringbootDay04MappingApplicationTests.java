package com.mapple.entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDay04MappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
