package org.comstudy.boardweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprIngbootEx07JpaJoinApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprIngbootEx07JpaJoinApplication.class, args);
	}

}
