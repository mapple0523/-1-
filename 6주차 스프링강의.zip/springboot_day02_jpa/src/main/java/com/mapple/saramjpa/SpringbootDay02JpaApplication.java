package com.mapple.saramjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDay02JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDay02JpaApplication.class, args);
	}

}
