package com.mapple.saramjpa.domain;

public class BoardEntity {

}
