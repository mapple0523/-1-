package com.mapple.saramjpa.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name ="SARAM") //테이블의 이름을 지정해줄수있음.
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaramEntity {
	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	//@id를 달아주면 바로아래있는것이 primary key가 된다.
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE) //Dialect에 지정되어있는 value의 값으로 자동 증가시켜줌
	private Long no;
	private String Id;
	private String Name;
	private int Age;
	
}
