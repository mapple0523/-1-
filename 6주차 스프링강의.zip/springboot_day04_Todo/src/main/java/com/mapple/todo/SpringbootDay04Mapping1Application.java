package com.mapple.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDay04Mapping1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDay04Mapping1Application.class, args);
	}

}
