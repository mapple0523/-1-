package com.mapple.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDay04Mapping1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
