package com.mapple.boardweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDay02JpaWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
