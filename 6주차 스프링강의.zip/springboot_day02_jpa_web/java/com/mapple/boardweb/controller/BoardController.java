package com.mapple.boardweb.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mapple.boardweb.domain.Board;
import com.mapple.boardweb.persistence.BoardRepository;
import com.mapple.boardweb.service.BoardService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardController {
	@Autowired
	BoardService boardservice = new BoardService();
	
	@GetMapping("/board/list")
	public String boardList(Model model) {
		List<Board> list = boardservice.selectAll();
		System.out.println(list.toString());
		model.addAttribute("list", list);
		return "board/list";
	}
	
	@GetMapping("/board/input")
	public String Input() {
		return "board/input";
	}
	
	@PostMapping("/board/input")
	public String boardInputProc(Board board) {
		boardservice.persist(board);
		
		return "redirect:/board/list";
	}
	
	@GetMapping("/board/delete")
	public String Delete() {
		return "board/delete";
	}
	
	@PostMapping("/board/delete")
	public String boardDeleteProc(Board board) {
		boardservice.delete(board);
		return "redirect:/board/list";
	}
	
	@GetMapping("/board/modfiy")
	public String Modify() {
		
		
		return "board/modify";
	}
	
	@PostMapping("/board/modfiy")
	public String ModifyProc(Board board) {
		return "redirect:/board/list";
	}
	
	@GetMapping("/board/detail")
	public String detail() {
		return "board/detail";
	}
	
	@PostMapping("/board/detail")
	public String detailProc(Board board) {
		boardservice.detail(board);
		
		return "redirect:/board/list";
	}
}
;