package com.mapple.boardweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapple.boardweb.domain.Board;
import com.mapple.boardweb.persistence.BoardRepository;

import lombok.RequiredArgsConstructor;

@Service
public class BoardService {
	@Autowired
	private BoardRepository boardRepository;
	
	public void persist(Board board) {
		boardRepository.save(board);
	}
	
	public void detail(Board board) {
		Long seq1 = board.getSeq();
		boardRepository.findById(seq1);
		}
	
	public void delete(Board board) {
		Long seq1 = board.getSeq();
		boardRepository.deleteById(seq1);
	}
	
	public List<Board> selectAll() {
		return (List)boardRepository.findAll(); 
	}
	
	
}
 