package com.mapple.saramproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDay02ThyApplicationTests {

	@Test
	void contextLoads() {
	}

}
