package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEx012ApplicationTests {

	@Test
	void contextLoads() {
	}

}
