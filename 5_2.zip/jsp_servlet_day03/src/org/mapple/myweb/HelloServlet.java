package org.mapple.myweb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// 서블랫 클래스는 HttpServlet을 상속 받아야한다.
public class HelloServlet extends HttpServlet {
	// 중요: 서블릿 실행 하는 방법은 web.xml에 매핑 시간 주소를 브라우저 주소창에 입력

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doget()- HelloServlet 호출됨");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");

		// 브라우저에 출력되는방식
		// Request객체에는 요청 정보(파라미터, session, uri 등)가 저장된다.
		// Response 객체에는 브라우저에 처리하는 정보가 저장된다.(화면에 그려지는 내용)

		PrintWriter out = resp.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("  <head>");
		out.println("    <title>Hello world</title>");
		out.println("  </head>");
		out.println("  <body>");
		out.println("    <h1>Hello world</h1>");
		out.println("<p><a href=\"http://www.naver.com\">네이버로 이동</a></p>");
		out.println("  </body>");
		out.println("</html>");

		out.close();
	}

	// 오버라이드(Override) - 부모 클래스의 멤버 매서드를 자식 클래스가 새 정의하는것
	// Override 어노테이션으로 검증
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}

	// 오버라이드(Override) - 부모 클래스의 멤버 메소드를 자식 클래스가 재 정의 하는것
	// @Override 어노테이션으로 검증
	// 우클릭 > source> override/impliment methods 부모클래스의 모든 자식클래스를 사용
	// 컨트롤 스페이스로 만들던가 오른쪽클릭으로 만들기

}
