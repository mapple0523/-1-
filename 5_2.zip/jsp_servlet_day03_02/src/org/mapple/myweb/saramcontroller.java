package org.mapple.myweb;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//web.xml에 servlet-mapping 해 주면 어노테이션 생략 가능
//@WebServlet("*.do")
public class saramcontroller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String ctxPath = req.getContextPath();
		String reqUri = req.getRequestURI();

		System.out.println("doget() - saramController 실행");

		System.out.printf("%s, %s\n", ctxPath, reqUri);

		String uriPattern = reqUri.substring(ctxPath.length());
		System.out.printf("%s", uriPattern);
		//view 페이지에서 사용될 변수 저장(request)
		//forward를 할때 request도 전달.
		//JSP 페이지에서 request.getArrtribute("username")으로 저장
		req.setAttribute("username", "홍길동" );
		//req에다가 username이 홍길동인걸 저장을하고 forward를하여서 jsp파일로 전달
		ArrayList<String> userList = new ArrayList<String>();
		userList.add("일길동 | 의사 | 28");
		userList.add("이길동 | 변호사 | 35");
		userList.add("삼길동 | 프로그래머 | 30");
		req.setAttribute("userList", userList);
		
		// view 페이지로 forward하기
		String viewName = "/WEB-INF/views/saram/list.jsp"; // view 역할 하는 jsp페이지의 위치
		RequestDispatcher view = req.getRequestDispatcher(viewName);
		//페이지 호출 없이 jsp파일 내에서 다른파일로 요청을 보내고 응답을 받는것
		// forward = servlet페이지에서 하는 일을 jsp페이지로 위임
		// request와 response 객체를 전달해줌
		
		view.forward(req, resp);
		//대상이 되는 자원으로 제어를 넘기는 문구(forward)
	}
}
