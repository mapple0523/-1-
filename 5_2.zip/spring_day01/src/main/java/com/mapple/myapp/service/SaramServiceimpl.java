package com.mapple.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapple.myapp.model.SaramDAO;
import com.mapple.myapp.model.SaramDTO;

@Service
public class SaramServiceimpl implements SaramService {
	@Autowired
	SaramDAO dao;

	@Override
	public List<SaramDTO> selectAll() {
		System.out.println(">>>selectAll():List<SaramDTO>- ServiceImpl실행");
		// TODO Auto-generated method stub
		dao.selectAll();
		return null;
	}

	@Override
	public SaramDTO selectOne(SaramDTO dto) {
		System.out.println(">>>selectOne():List<SaramDTO>- ServiceImpl실행");
		// TODO Auto-generated method stub
		dao.selectOne(dto);
		return null;
	}

	@Override
	public void insert(SaramDTO dto) {
		System.out.println(">>>Insert():List<SaramDTO>- ServiceImpl실행");
		// TODO Auto-generated method stub
		dao.insert(dto);

	}

	@Override
	public void update(SaramDTO dto) {
		System.out.println(">>>update():List<SaramDTO>- ServiceImpl실행");
		// TODO Auto-generated method stub
		dao.update(dto);
	}

	@Override
	public void delete(SaramDTO dto) {
		System.out.println(">>>delete():List<SaramDTO>- ServiceImpl실행");
		// TODO Auto-generated method stub
		dao.delete(dto);
	}

}
