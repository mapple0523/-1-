package org.mapple.myweb;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mapple.myweb.model.SaramDTO;

public class DispathcerServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doget()- 실행");
		
		SaramDTO saram1 = new SaramDTO(1, "hong", "홍길동", 25);
		
		req.setAttribute("saram1", saram1);
		
		String viewName = "/WEB-INF/views/saram/list.jsp";
		RequestDispatcher view = req.getRequestDispatcher(viewName);
		view.forward(req, resp);
		
		
	}
}
