package org.mapple.myweb.model;

public class SaramDTO {
	int seq;
	String id;
	String name;
	int age;
	
	public SaramDTO() {
		// TODO Auto-generated constructor stub
	} 
	//디폴트 생성자 = 매게변수가 없는 생성자
	//생성자 오버로딩 된 상황에서는 개발자가 직접 만들어야함.
	//생성자가 하나도 없다면 컴파일러가 컴파일 하기위해 자동으로 생성한다.

	public SaramDTO(int seq, String id, String name, int age) {
		// TODO Auto-generated constructor stub
		//오버로딩: 같은 이름의 매서드가 같은 클래스에 여러개 존재 할 수있음
		//오버로딩의 시그니처는 매개변수와 타입과 이름이 달라야 한다.
		
		//필드의 이름과 매게변수의 이름이 동일할때는 구분을 위해서 필드앞에 this를 붙인다
		this.seq = seq;
		this.id = id;
		this.name = name;
		this.age = age;
		System.out.printf("%d,%s,%s,%d", seq,id,name,age);
	}
	
}
