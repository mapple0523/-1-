package org.mapple.myweb;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mapple.myweb.board.model.BoardDAO;
import org.mapple.myweb.board.model.BoardDTO;
import org.mapple.myweb.model.SaramDAO;
import org.mapple.myweb.model.SaramDTO;

public class DispathcerServlet extends HttpServlet {
	
	SaramDAO saramDAO = new SaramDAO();
	BoardDAO boardDAO = new BoardDAO();
	SaramController saramController = new SaramController();

	private String encodingWork(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");

		// path 만들기
		String ctxPath = req.getContextPath();
		String reqUri = req.getRequestURI();
		String path = reqUri.substring(ctxPath.length());
		System.out.println(path);
		// 하위 컨트롤러에서 사용하도록 req에 저장
		req.setAttribute("path", path);
		return path;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doget()- 실행");
		
		String path = encodingWork(req, resp);
		
		Controller controller = new BoradController();
		if (path.indexOf("/saram") != -1) {
			controller = saramController;
		} else if (path.indexOf("/board") != -1) {
			controller = new BoradController();
		}

		String viewName = controller.process(req, resp);

		RequestDispatcher view = req.getRequestDispatcher(viewName);
		view.forward(req, resp);
	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doPost() - DispatcherServlet 요청");
		String path = encodingWork(req, resp);
		
		
		int seq = Integer.parseInt(req.getParameter("seq") == null ? "0" : req.getParameter("seq"));
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age") == null ? "0" : req.getParameter("age"));
		
		long seq1 = Long.parseLong(req.getParameter("seq")==null ? "0": req.getParameter("seq"));
		
		
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String writeDate = req.getParameter("writeDate");
		String writer = req.getParameter("writter");
		long cnt = Long.parseLong(req.getParameter("cnt"));
		
		BoardDTO dto2 = new BoardDTO(seq1,title,content,writeDate,writer,cnt);
		SaramDTO dto = new SaramDTO(seq, id, name, age);
		if("/saram/input.do".indexOf(path) != -1) {
			saramDAO.save(dto);
			resp.sendRedirect(req.getContextPath() + "/saram/list.do");
		} else if("/saram/modify.do".indexOf(path) != -1) {
			System.out.println("사람 수정요청");
			saramDAO.update(dto);
			resp.sendRedirect(req.getContextPath() + "/saram/list.do");
		} else if("/board/input.do".indexOf(path) != -1) {
			System.out.println("보드 입력 요청");
			boardDAO.save(dto2);
			resp.sendRedirect(req.getContextPath() + "/board/list.do");
		} else if("/board/modify.do".indexOf(path) != -1) {
			System.out.println("보드 수정 요청");
			boardDAO.update(dto2);
			resp.sendRedirect(req.getContextPath() + "/saram/list.do");
		}

		}

	};