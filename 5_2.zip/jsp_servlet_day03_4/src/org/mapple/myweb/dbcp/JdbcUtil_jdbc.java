package org.mapple.myweb.dbcp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcUtil_jdbc {

	public static Connection getConnection()  {
		// TODO Auto-generated method stub
		// JDBC 연동- 커넥션 드라이버 찾기

		String url = "jdbc:h2:tcp://localhost/~/test";
		String user = "sa";
		String password = "";
		// 드라이버를 검색하고 인스턴스화 시켜줌
		// src에서 buld path- config buildpath를 이용해서 h2연동
		Connection conn = null;
		try {
			Class.forName("org.h2.Driver");// 드라이버 검색->인스턴스화
			System.out.println("드라이버 검색 성공");
			conn = DriverManager.getConnection(url, user, password);
			return conn;
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버 검색 실패");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("SQL 오류");
			e.printStackTrace();
		}
		return conn;
	}
	//static멤버 -class멤버 : 클래스 외부에서 객체 생성 없이 클래스명으로 접근 가능.
	public static void close(Connection obj) {
		if(obj !=null)
			try {
				obj.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	public static void close(ResultSet obj) {
		if(obj !=null)
			try {
				obj.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	public static void close(Statement obj) {
		if(obj !=null)
			try {
				obj.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	//메소드 오버로딩
	
	public static void close(Connection conn, Statement stmt, ResultSet rs ) {
		close(rs);
		close(stmt);
		close(conn);
	}
	
	

}
