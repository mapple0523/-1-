package org.mapple.myweb.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.mapple.myweb.dbcp.JdbcUtil;

public class SaramDAO {
	// Database에 CRUD를 전담하는 클래스
	
	Connection conn = null; //디비 연결 용도
	PreparedStatement stmt = null;//디비에 SQL 전달
	ResultSet rs = null;//결과를 받아 올때 사용
	
	//preparedstatement는 변수처리를 ?표로 할수있음
	
	//상수
	final String FIND_ALL =  "SELECT * FROM SARAM";
	final String FIND_ONE = "SELECT * FROM SARAM WHERE SEQ=?";
	final String SAVE = "INSERT INTO SARAM (id, name, age) values(?,?,?)";
	final String UPDATE = "update saram set id=?, name=?, age=? WHERE seq=?";
	final String DELETE = "DELETE from saram WHERE seq=?";
	
	//검색
	public List<SaramDTO> findAll() {
		List<SaramDTO> list = new ArrayList<SaramDTO>();
		try {
			conn = JdbcUtil.getConnection();
			stmt = conn.prepareStatement(FIND_ALL);
			rs = stmt.executeQuery();
			while(rs.next()) {
				int seq = rs.getInt("seq");
				String id = rs.getString("id");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				list.add(new SaramDTO(seq,id,name,age));
			} //반복하면서 계속 실행되는것.
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		return list;
	}
	
	
	public SaramDTO findOne(SaramDTO dto) {
		SaramDTO saram = null;
		try {
			conn = JdbcUtil.getConnection();
			stmt = conn.prepareStatement(FIND_ONE);
			stmt.setInt(1,  dto.getSeq());
			rs = stmt.executeQuery();
			if (rs.next()) {
				int seq = rs.getInt("seq");
				String id = rs.getString("id");
				String name = rs.getString("name");
				int age = rs.getInt("age");
				saram = new SaramDTO(seq,id,name,age);
			} //반복하면서 계속 실행되는것.
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		
		return saram;
	}
	
	public void save(SaramDTO dto) {
		try {
			conn = JdbcUtil.getConnection();
			stmt = conn.prepareStatement(SAVE);
			stmt.setString(1,  dto.getId());
			stmt.setString(2,  dto.getName());
			stmt.setInt(3, dto.getAge());
			int cnt = stmt.executeUpdate();
			//트랜잭션을 확용하여서 성공하면 커밋 아니면 롤백
			if(cnt>0) {
				System.out.println("입력 성공");
				conn.commit();
			} else {
				System.out.println("입력 실패");
				conn.rollback();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}
	
	public void update(SaramDTO dto) {
		try {
			conn = JdbcUtil.getConnection();
			stmt = conn.prepareStatement(UPDATE);
			stmt.setString(1,  dto.getId());
			stmt.setString(2,  dto.getName());
			stmt.setInt(3, dto.getAge());
			stmt.setInt(4,  dto.getSeq());
			int cnt = stmt.executeUpdate();
			if(cnt>0) {
				System.out.println("입력 성공");
				conn.commit();
			} else {
				System.out.println("입력 실패");
				conn.rollback();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}
	
	public void delete(SaramDTO dto) {
		try {
			conn = JdbcUtil.getConnection();
			stmt = conn.prepareStatement(DELETE);
			stmt.setInt(1,  dto.getSeq());
			int cnt = stmt.executeUpdate();
			if(cnt>0) {
				System.out.println("삭제 성공");
				conn.commit();
			} else {
				System.out.println("삭제 실패");
				conn.rollback();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		
	}
	
	
	
	public static void main(String[] args) {
		//어플리케이션 테스트
		// JNDI는 톰캣에서 테스트 해야 한다.
		// main()에서 실행 하면 톰캣과 별도로 실행된다.
		testFindAll();
	}
	
	public static void testFindAll() {
		SaramDAO dao = new SaramDAO();
		List<SaramDTO> saramList = (List<SaramDTO>)dao.findAll();
		for(int i=0; i<saramList.size(); i++) {
			System.out.println(saramList.get(i));
		}
	}
}
 