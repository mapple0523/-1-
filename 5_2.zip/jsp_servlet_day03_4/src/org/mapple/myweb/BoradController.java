package org.mapple.myweb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mapple.myweb.board.model.BoardDAO;
import org.mapple.myweb.board.model.BoardDTO;
import org.mapple.myweb.model.SaramDAO;
import org.mapple.myweb.model.SaramDTO;

public class BoradController implements Controller {

	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = (String) req.getAttribute("path");
		System.out.println(path);

		// SaramDTO 객체(Bean)가 저장된 List를 view 페이지에 전달 하기.

		BoardDAO dao = new BoardDAO();

		String viewName = "/WEB-INF/views/board/home.jsp";
		if (path.indexOf("/input.do") != -1) {
			viewName = "/WEB-INF/views/board/input.jsp";
		} else if (path.indexOf("/detail.do") != -1) {
			viewName = "/WEB-INF/views/board/modify.jsp";
		} else if (path.indexOf("/modify.do") != -1) {
			BoardDTO dto = new BoardDTO();
			// 링크에서 쿼리스트링으로 전달 된 seq 값을 받아서 출력한다.
			dto.setSeq(Long.parseLong(req.getParameter("seq")));
			BoardDTO board = dao.findOne(dto);
			req.setAttribute("board", board);
			viewName = "/WEB-INF/views/board/modify.jsp";
		} else {
			List<BoardDTO> list = dao.findAll();
			req.setAttribute("list", list);
			viewName = "/WEB-INF/views/board/list.jsp";
		}

		return viewName;

	}
}
