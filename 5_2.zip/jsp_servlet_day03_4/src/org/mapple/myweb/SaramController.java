package org.mapple.myweb;

import java.io.IOException;

import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mapple.myweb.model.SaramDAO;
import org.mapple.myweb.model.SaramDTO;

public class SaramController implements Controller {
	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String path = (String)req.getAttribute("path");
		System.out.println(path);
		
		// SaramDTO 객체(Bean)가 저장된 List를 view 페이지에 전달 하기.

		SaramDAO dao = new SaramDAO();
		

		String viewName = "/WEB-INF/views/saram/home.jsp";
		if(path.indexOf("/input.do")!= -1) {
			viewName = "/WEB-INF/views/saram/input.jsp";
		} else if(path.indexOf("/detail.do")!= -1) {
			viewName = "/WEB-INF/views/saram/detail.jsp";
		} else if(path.indexOf("/modify.do")!= -1) {
			SaramDTO dto = new SaramDTO();
			//링크에서 쿼리스트링으로 전달 된 seq 값을 받아서 출력한다.
			dto.setSeq(Integer.parseInt(req.getParameter("seq")));
			SaramDTO saram = dao.findOne(dto);
			req.setAttribute("saram", saram);
			viewName = "/WEB-INF/views/saram/modify.jsp";
		}  else {
			List<SaramDTO> list = dao.findAll();
			req.setAttribute("list", list);
			viewName = "/WEB-INF/views/saram/list.jsp";
		}
		
		return viewName;

	}
}
