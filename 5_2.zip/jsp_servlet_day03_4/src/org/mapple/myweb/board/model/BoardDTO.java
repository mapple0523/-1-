package org.mapple.myweb.board.model;

import java.util.Date;

public class BoardDTO {
	private Long seq;
	private String title;
	private String content;
	private String writeDate;
	private String writter;
	private Long cnt;

	public BoardDTO() {
		this(0L, "", "","", "", 0L);
	}

	public BoardDTO(Long seq, String title, String content, String writeDate, String writter, Long cnt) {
		this.seq = seq;
		this.title = title;
		this.content = content;
		this.writeDate = writeDate;
		this.writter = writter;
		this.cnt = cnt;
	}

	public Long getSeq() {
		return this.seq;
	}

	public void setSeq(Long seq) {
		this.seq = seq;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriteDate() {
		return this.writeDate;
	}

	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}
	
	public String getWritter() {
		return this.writter;
	}

	public void setWritter(String writter) {
		this.writter = writter;
	}

	public Long getCnt() {
		return this.cnt;
	}

	public void setCnt(Long cnt) {
		this.cnt = cnt;
	}

	public String toString() {
		return "BoardDTO [seq=" + this.seq + ", title=" + this.title + ", content=" + this.content + ", writeDate="
				+ this.writeDate + ", writter=" + this.writter + ", cnt=" + this.cnt + "]";
	}

	public int hashCode() {
		boolean prime = true;
		int result = 1;
		int result1 = 31 * result + (this.seq == null ? 0 : this.seq.hashCode());
		return result1;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (obj == null) {
			return false;
		} else if (this.getClass() != obj.getClass()) {
			return false;
		} else {
			BoardDTO other = (BoardDTO) obj;
			if (this.seq == null) {
				if (other.seq != null) {
					return false;
				}
			} else if (!this.seq.equals(other.seq)) {
				return false;
			}

			return true;
		}
	}
}