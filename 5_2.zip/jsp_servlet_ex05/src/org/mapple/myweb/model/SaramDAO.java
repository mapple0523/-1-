package org.mapple.myweb.model;


import java.util.List;

public class SaramDAO {

	//검색
	public List<SaramDTO> findAll() {
		List<SaramDTO> list = null;
		return list;
	}
	public SaramDTO findOne(SaramDTO dto) {
		SaramDTO saram = null;
		return saram;
	}
	
	public void save(SaramDTO dto) {
	}
	
	public void update(SaramDTO dto) {
	}
	
	public void delete(SaramDTO dto) {
		
	}
	
	
	
	public static void main(String[] args) {
		//어플리케이션 테스트
		// JNDI는 톰캣에서 테스트 해야 한다.
		// main()에서 실행 하면 톰캣과 별도로 실행된다.
		testFindAll();
	}
	
	public static void testFindAll() {
		SaramDAO dao = new SaramDAO();
		List<SaramDTO> saramList = (List<SaramDTO>)dao.findAll();
		for(int i=0; i<saramList.size(); i++) {
			System.out.println(saramList.get(i));
		}
	}
}
 