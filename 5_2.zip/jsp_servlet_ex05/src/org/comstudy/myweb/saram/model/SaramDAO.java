package org.comstudy.myweb.saram.model;

import java.util.List;

public class SaramDAO {

	public List<SaramDTO> findAll() {
		List<SaramDTO> list = null;
		return list;
	}

	public SaramDTO findOne(SaramDTO dto) {
		SaramDTO saram = null;
		return saram;
	}

	// 입력
	public void save(SaramDTO dto) {
		
	}

	// 수정
	public void update(SaramDTO dto) {
		
	}

	// 삭제
	public void remove(SaramDTO dto) {
		
	}
}
