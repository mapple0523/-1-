package com.mapple.myapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.mapple.myapp.model.Saram;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 웹에서 실행되지않음
		System.out.println("Hello spring world");

//		Saram saram = new Saram(12, "KIM", "김유신","감자", 35);
//		System.out.println(saram);

		//applicationContext.xml에 선언된 Bean 객체를 Lookup 해서 사용하기
		String resource = "classpath:applicationContext.xml";
		AbstractApplicationContext factory =
				new GenericXmlApplicationContext(resource);
		Saram saram = (Saram)factory.getBean("Saram");
		//getBean으로 들고오는것은 전부 object이기때문에 형 변환을 해야함
		System.out.println(saram);
		
	}

}
