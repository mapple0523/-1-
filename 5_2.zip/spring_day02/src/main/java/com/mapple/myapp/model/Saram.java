package com.mapple.myapp.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Saram {
	private int idx;
	private String id;
	private String name;
	private String address;
	private int age;
}

//스프링 프로젝트 내보내기 (file-exports)
