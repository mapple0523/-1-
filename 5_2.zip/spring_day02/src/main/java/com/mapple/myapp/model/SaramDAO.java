package com.mapple.myapp.model;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

// 클래스 선언 및 bean 등록
@Repository
public class SaramDAO {
	
	public ArrayList<Saram> selectAll() {
		System.out.println("SerectAll 호출됨");
		return null;
		//selectAll 이라는 함수를 만듬
	}
}
