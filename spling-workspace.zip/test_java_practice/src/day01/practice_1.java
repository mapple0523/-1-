package day01;

public class practice_1 {
	public static void main(String[] args) {
		System.out.println("12345");
		
		String name="JAVA";
				
		System.out.println("Hello " + name + " world");
	}
}